var class_nex_page =
[
    [ "NexPage", "class_nex_page.html#a8608a0400bd8e27466ca4bbc05b5c2a0", null ],
    [ "show", "class_nex_page.html#a5714e41d4528b991eda4bbe578005418", null ]
];