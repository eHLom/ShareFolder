var class_nex_slider =
[
    [ "NexSlider", "class_nex_slider.html#a00c5678209c936e9a57c14b6e2384774", null ],
    [ "Get_background_color_bco", "class_nex_slider.html#a1cf49184702852c0623a695f4b62b1ed", null ],
    [ "Get_cursor_height_hig", "class_nex_slider.html#a680c31b1aa2dc48a1193c9d8fb3cd487", null ],
    [ "Get_font_color_pco", "class_nex_slider.html#aa6361627b3c66ee7a569b5cfec4ce562", null ],
    [ "Get_pointer_thickness_wid", "class_nex_slider.html#a6adbc43b663e3542a92641c406db23ad", null ],
    [ "getMaxval", "class_nex_slider.html#abf1b50605feb0ac2b381d1148795f0d9", null ],
    [ "getMinval", "class_nex_slider.html#ab98752f15d56dc04de102c0c2180ea11", null ],
    [ "getValue", "class_nex_slider.html#a384d5488b421efd6affbfd32f45bb107", null ],
    [ "Set_background_color_bco", "class_nex_slider.html#ac22c66fecb8cf03d554c3c86e6e798d5", null ],
    [ "Set_cursor_height_hig", "class_nex_slider.html#a603cf3685c6d843261d8552030af9f22", null ],
    [ "Set_font_color_pco", "class_nex_slider.html#acc766d430c7a663846e4da6e1bacf76c", null ],
    [ "Set_pointer_thickness_wid", "class_nex_slider.html#a6b91c1f7fddf7ea1b62c406453110ead", null ],
    [ "setMaxval", "class_nex_slider.html#a5a1c65a9f2e21a624b78d5817d695503", null ],
    [ "setMinval", "class_nex_slider.html#ad38503fd3a6bfe3eaaa57764ac90f244", null ],
    [ "setValue", "class_nex_slider.html#a3f325bda4db913e302e94a4b25de7b5f", null ]
];