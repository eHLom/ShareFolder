﻿@TwoDisplays

# Enhanced Nextion Library multi instance support

In this example two displays connected in the one board.
Slider value shown in other display both displays uses same Nextion UI code