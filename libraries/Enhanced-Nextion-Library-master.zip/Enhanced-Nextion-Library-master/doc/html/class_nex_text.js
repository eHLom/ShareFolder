var class_nex_text =
[
    [ "NexText", "class_nex_text.html#a31369d9ab068aeb7e457d5322f96fc76", null ],
    [ "NexText", "class_nex_text.html#a00a47e105c7c279491d42d91648ae7e4", null ],
    [ "appendText", "class_nex_text.html#a7603acf98170cef152ccd028bc5abaf3", null ],
    [ "Get_background_color_bco", "class_nex_text.html#aae462cf7787d0b9836fb8576d9fd1b94", null ],
    [ "Get_background_crop_picc", "class_nex_text.html#ada43e96124d049d1b2c42093919c9df3", null ],
    [ "Get_background_image_pic", "class_nex_text.html#a539368fe23d2f2ea5f5f406f339662b5", null ],
    [ "Get_font_color_pco", "class_nex_text.html#adf8f519bc2a17412a98cc5f3349e44ab", null ],
    [ "Get_place_xcen", "class_nex_text.html#ac3cd350dd9a49ecdf179028e3e54ee22", null ],
    [ "Get_place_ycen", "class_nex_text.html#a4c4099af04356461af3b29afe8f59893", null ],
    [ "getFont", "class_nex_text.html#ae033684f53bec0df70d57847050071f9", null ],
    [ "getText", "class_nex_text.html#a689e18a543703dd84024a5a047321b9e", null ],
    [ "getText", "class_nex_text.html#a325807754fd78f6c1651308687cbb105", null ],
    [ "Set_background_color_bco", "class_nex_text.html#a1b1586e5e66d76a4f8f5c40b0986f471", null ],
    [ "Set_background_crop_picc", "class_nex_text.html#a3727463a4fc0e1df978cd8fc7d1103ed", null ],
    [ "Set_background_image_pic", "class_nex_text.html#ab2c85ac7d5184e124b0cd724028c1915", null ],
    [ "Set_font_color_pco", "class_nex_text.html#ab59df7e777198eefb422ba2081d0cfce", null ],
    [ "Set_place_xcen", "class_nex_text.html#ab94a4b8505a9bfdf8fb4cb8cb32a1763", null ],
    [ "Set_place_ycen", "class_nex_text.html#a0f8ad9780c8145569da6736d0ee494e4", null ],
    [ "setFont", "class_nex_text.html#a5dd7fdda945a76033ef8fe8dc68e3e52", null ],
    [ "setText", "class_nex_text.html#a19589b32c981436a1bbcfe407bc766e3", null ]
];