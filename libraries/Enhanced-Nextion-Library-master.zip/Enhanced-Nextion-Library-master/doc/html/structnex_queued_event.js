var structnex_queued_event =
[
    [ "event_data", "structnex_queued_event.html#a259d03e4d27b347c76384cab768af5dd", null ],
    [ "m_next", "structnex_queued_event.html#a4cbcd7e2488fe929ae75b8c55bc69790", null ]
];