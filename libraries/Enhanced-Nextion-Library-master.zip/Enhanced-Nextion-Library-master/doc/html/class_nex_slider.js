var class_nex_slider =
[
    [ "NexSlider", "class_nex_slider.html#a9a5369beaca086d038fe8c297fdfe8cb", null ],
    [ "NexSlider", "class_nex_slider.html#af0d7d4ba3e5b8cc8ac2f79166d34c663", null ],
    [ "Get_background_color_bco", "class_nex_slider.html#aaf4e36e65a528d14b7d635d0bfb14545", null ],
    [ "Get_background_image_pic", "class_nex_slider.html#a2e041187eaf47a3a166883a7fd45a15b", null ],
    [ "Get_background_image_picc", "class_nex_slider.html#a6f1d596446e2c394f40cf6df26ca8fd0", null ],
    [ "Get_cursor_height_hig", "class_nex_slider.html#a7756b136ffb6d5825334a0f75a2b01b6", null ],
    [ "Get_font_color_pco", "class_nex_slider.html#a4e84de45ba6eb0047f95e0d0b4a33412", null ],
    [ "Get_pointer_thickness_wid", "class_nex_slider.html#aff00d63f5b2bd8ac0b3d370bd5f2fe52", null ],
    [ "getMaxval", "class_nex_slider.html#a0a51a65d17314b36e7e3558707c26dad", null ],
    [ "getMinval", "class_nex_slider.html#ae3621dae5fa8be950ab6604ab22a883f", null ],
    [ "getValue", "class_nex_slider.html#a384d5488b421efd6affbfd32f45bb107", null ],
    [ "Set_background_color_bco", "class_nex_slider.html#ac22c66fecb8cf03d554c3c86e6e798d5", null ],
    [ "Set_background_image_pic", "class_nex_slider.html#a1d513645974220e99fc2cf46b0f245b4", null ],
    [ "Set_background_image_picc", "class_nex_slider.html#a886f6924a641d6f61cd67d4c87fa38cd", null ],
    [ "Set_cursor_height_hig", "class_nex_slider.html#a603cf3685c6d843261d8552030af9f22", null ],
    [ "Set_font_color_pco", "class_nex_slider.html#acc766d430c7a663846e4da6e1bacf76c", null ],
    [ "Set_pointer_thickness_wid", "class_nex_slider.html#a6b91c1f7fddf7ea1b62c406453110ead", null ],
    [ "setMaxval", "class_nex_slider.html#a5a1c65a9f2e21a624b78d5817d695503", null ],
    [ "setMinval", "class_nex_slider.html#ad38503fd3a6bfe3eaaa57764ac90f244", null ],
    [ "setValue", "class_nex_slider.html#a3f325bda4db913e302e94a4b25de7b5f", null ]
];