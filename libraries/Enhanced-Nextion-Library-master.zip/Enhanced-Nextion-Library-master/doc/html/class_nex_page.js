var class_nex_page =
[
    [ "NexPage", "class_nex_page.html#adcc75d98da1e3fe02f2b6c92766e14a7", null ],
    [ "NexPage", "class_nex_page.html#a04ae41ca9e2be5abcfd759416834142c", null ],
    [ "setVisibleAll", "class_nex_page.html#a673d110a8a3249ca3601088a459c3ab2", null ],
    [ "show", "class_nex_page.html#a5714e41d4528b991eda4bbe578005418", null ]
];