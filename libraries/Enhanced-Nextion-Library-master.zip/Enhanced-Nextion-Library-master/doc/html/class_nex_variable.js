var class_nex_variable =
[
    [ "NexVariable", "class_nex_variable.html#a53f97d4a1c908894acafe24f8006c8e5", null ],
    [ "NexVariable", "class_nex_variable.html#a7cf22689c05691f5525a39202f74a60c", null ],
    [ "attachPush", "class_nex_variable.html#a01e5fd5361cb7603a1a6bfbde09b6806", null ],
    [ "getText", "class_nex_variable.html#a47a201aac611afe50a4b3b2f83d17157", null ],
    [ "getText", "class_nex_variable.html#a0b2b6bc3fdaf1cfc06682ab1ceb897a3", null ],
    [ "getValue", "class_nex_variable.html#a8c3de285ece4e7d96838c95b0ff2a58a", null ],
    [ "setText", "class_nex_variable.html#aab59ac44eb0804664a03c09932be70eb", null ],
    [ "setValue", "class_nex_variable.html#adb15147ce38166eba12dfb2abea0dbb2", null ]
];