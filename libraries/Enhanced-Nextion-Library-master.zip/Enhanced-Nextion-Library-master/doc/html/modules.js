var modules =
[
    [ "Component", "group___component.html", "group___component" ],
    [ "Configuration", "group___configuration.html", "group___configuration" ],
    [ "CoreAPI", "group___core_a_p_i.html", "group___core_a_p_i" ],
    [ "TouchEvent", "group___touch_event.html", "group___touch_event" ]
];