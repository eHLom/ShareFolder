var class_nex_hotspot =
[
    [ "NexHotspot", "class_nex_hotspot.html#a61407fae43ec70e42826363df973fa17", null ],
    [ "NexHotspot", "class_nex_hotspot.html#addfae63499b750a863b195421a771460", null ]
];