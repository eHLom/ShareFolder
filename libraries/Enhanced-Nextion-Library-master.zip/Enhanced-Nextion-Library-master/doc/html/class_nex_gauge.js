var class_nex_gauge =
[
    [ "NexGauge", "class_nex_gauge.html#a38400023bc6333d06fa80c1271d62ea4", null ],
    [ "NexGauge", "class_nex_gauge.html#a8219ceebaa70e4b0427b4c3ee1885f94", null ],
    [ "Get_background_color_bco", "class_nex_gauge.html#a95c199438866ab2c2d16c3b624b3e5ae", null ],
    [ "Get_background_cropi_picc", "class_nex_gauge.html#ad4fd8254b08666679d000ebc17eb402a", null ],
    [ "Get_font_color_pco", "class_nex_gauge.html#a6d598c7a3f48a7f3031833060bc5b64e", null ],
    [ "Get_pointer_thickness_wid", "class_nex_gauge.html#a49784509a3dbc8f5186833e9260608cf", null ],
    [ "getValue", "class_nex_gauge.html#aeea8933513ebba11584ad97f8c8b5e69", null ],
    [ "Set_background_color_bco", "class_nex_gauge.html#a2d2fe2d81da81e14a66260c501d644b3", null ],
    [ "Set_background_crop_picc", "class_nex_gauge.html#a223fa8a91a87439047f22ca1c33660df", null ],
    [ "Set_font_color_pco", "class_nex_gauge.html#ace00cba20b5cf5e1374c1a57bbf9a5f5", null ],
    [ "Set_pointer_thickness_wid", "class_nex_gauge.html#adacdbcb25fdf45654ebc88f572e3bce9", null ],
    [ "setValue", "class_nex_gauge.html#a448ce9ad69f54c156c325d578a96b765", null ]
];