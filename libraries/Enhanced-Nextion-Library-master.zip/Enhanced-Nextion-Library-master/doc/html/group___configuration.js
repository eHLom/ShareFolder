var group___configuration =
[
    [ "dbSerialBegin", "group___configuration.html#gabec12d271fea8fd82696961bc9339edf", null ],
    [ "dbSerialPrint", "group___configuration.html#gaf018322c574c0f39d5feb76995cdf2d6", null ],
    [ "dbSerialPrintln", "group___configuration.html#ga7792c838c043fae9a630823f1c328a30", null ],
    [ "NEX_ENABLE_HW_SERIAL", "group___configuration.html#ga5446baadd7f775404556a957cf6d03fc", null ],
    [ "NEX_ENABLE_SW_SERIAL", "group___configuration.html#ga90ca07f4dc231d7b3ecd20d615315445", null ],
    [ "NEX_SERIAL_DEFAULT_BAUD", "group___configuration.html#ga0d9afe49b80c7a5c460c0fd86f3c10ff", null ],
    [ "NEX_TIMEOUT_COMMAND", "group___configuration.html#gab669a035a97723735f7a2003f7839f81", null ],
    [ "NEX_TIMEOUT_RETURN", "group___configuration.html#ga5ae87f8c93cd3b2f119ea3708ca4f049", null ],
    [ "NEX_TIMEOUT_STANDARD", "group___configuration.html#ga5e399427a4fb32529f5af170aae6ddc5", null ],
    [ "NEX_TIMEOUT_TRANSPARENT_DATA_MODE", "group___configuration.html#ga2c6a26713ffadd18a4d56a3f8ea357ed", null ]
];