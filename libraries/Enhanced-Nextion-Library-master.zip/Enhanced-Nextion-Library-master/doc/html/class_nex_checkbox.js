var class_nex_checkbox =
[
    [ "NexCheckbox", "class_nex_checkbox.html#a90d4800c92291a7e08ebf4b4aff6a996", null ],
    [ "NexCheckbox", "class_nex_checkbox.html#a23f7690959945acce03485b8cbd06233", null ],
    [ "attachPush", "class_nex_checkbox.html#a273e23a7616defd20a417c2f200bcc75", null ],
    [ "Get_background_color_bco", "class_nex_checkbox.html#a43185a735cdb98c3901cf5b10620c133", null ],
    [ "Get_font_color_pco", "class_nex_checkbox.html#a3704ede0978401364cb94c325a556355", null ],
    [ "getValue", "class_nex_checkbox.html#ac31caa96ae0627f928bce2302224e89b", null ],
    [ "Set_background_color_bco", "class_nex_checkbox.html#ab430ba5908c84fea8ab910002581350a", null ],
    [ "Set_font_color_pco", "class_nex_checkbox.html#aa1d52cc0170f11ec85263770fe77db2a", null ],
    [ "setValue", "class_nex_checkbox.html#aa932e7c45765400618dce1804766264b", null ]
];