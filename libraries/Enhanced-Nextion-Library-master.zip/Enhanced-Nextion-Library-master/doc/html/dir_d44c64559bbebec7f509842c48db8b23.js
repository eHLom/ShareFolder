var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "NexButton.h", "_nex_button_8h.html", null ],
    [ "NexCheckbox.h", "_nex_checkbox_8h.html", null ],
    [ "NexConfig.h", "_nex_config_8h.html", "_nex_config_8h" ],
    [ "NexCrop.h", "_nex_crop_8h.html", null ],
    [ "NexDualStateButton.h", "_nex_dual_state_button_8h.html", null ],
    [ "NexGauge.h", "_nex_gauge_8h.html", null ],
    [ "NexGpio.h", "_nex_gpio_8h.html", null ],
    [ "NexHardware.h", "_nex_hardware_8h.html", [
      [ "nexQueuedEvent", "structnex_queued_event.html", "structnex_queued_event" ]
    ] ],
    [ "NexHardwareInterface.h", "_nex_hardware_interface_8h.html", null ],
    [ "NexHotspot.h", "_nex_hotspot_8h.html", null ],
    [ "NexNumber.h", "_nex_number_8h.html", null ],
    [ "NexObject.h", "_nex_object_8h.html", null ],
    [ "NexPage.h", "_nex_page_8h.html", null ],
    [ "NexPicture.h", "_nex_picture_8h.html", null ],
    [ "NexProgressBar.h", "_nex_progress_bar_8h.html", null ],
    [ "NexRadio.h", "_nex_radio_8h.html", null ],
    [ "NexRtc.h", "_nex_rtc_8h.html", null ],
    [ "NexScrolltext.h", "_nex_scrolltext_8h.html", null ],
    [ "NexSlider.h", "_nex_slider_8h.html", null ],
    [ "NexText.h", "_nex_text_8h.html", null ],
    [ "NexTimer.h", "_nex_timer_8h.html", null ],
    [ "Nextion.h", "_nextion_8h.html", null ],
    [ "NextionIf.h", "_nextion_if_8h.html", null ],
    [ "NexTouch.h", "_nex_touch_8h.html", "_nex_touch_8h" ],
    [ "NexUpload.h", "_nex_upload_8h.html", null ],
    [ "NexVariable.h", "_nex_variable_8h.html", null ],
    [ "NexWaveform.h", "_nex_waveform_8h.html", null ]
];