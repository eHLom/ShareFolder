var _nex_touch_8h =
[
    [ "NEX_EVENT_POP", "group___touch_event.html#ga5db3d99f88ac878875ca47713b7a54b6", null ],
    [ "NEX_EVENT_PUSH", "group___touch_event.html#ga748c37a9bbe04ddc680fe1686154fefb", null ],
    [ "NexTouchEventCb", "group___touch_event.html#ga95f5c2ce3d34b0b7e7d2cac3076a768e", null ]
];