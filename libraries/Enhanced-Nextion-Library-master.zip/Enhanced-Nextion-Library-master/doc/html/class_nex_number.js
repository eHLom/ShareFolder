var class_nex_number =
[
    [ "NexNumber", "class_nex_number.html#ac6c623708bca1b430587bf9d49cc2426", null ],
    [ "NexNumber", "class_nex_number.html#ac8b6b54157ed46f236c50dd32bddbd4e", null ],
    [ "Get_background_color_bco", "class_nex_number.html#ac43139f174b3488ad7c73b0519a89fa8", null ],
    [ "Get_background_crop_picc", "class_nex_number.html#a75228c46583d06f1eb12c21a2471720a", null ],
    [ "Get_background_image_pic", "class_nex_number.html#ab7385399a058983cecd6207be2a2a2ef", null ],
    [ "Get_font_color_pco", "class_nex_number.html#a6343d187babbd8bd167340dfb2aabee6", null ],
    [ "Get_number_lenth", "class_nex_number.html#aa719c1d22857913a62914846b5894d6c", null ],
    [ "Get_place_xcen", "class_nex_number.html#a022b34eccb09055b9a8ff01f0d7d1e8a", null ],
    [ "Get_place_ycen", "class_nex_number.html#ae629dc8faa4a0c1aca24557e7906a415", null ],
    [ "getFont", "class_nex_number.html#a4391f0ae9ed3b2e7f253c45c43fdf929", null ],
    [ "getValue", "class_nex_number.html#ad184ed818666ec482efddf840185c7b8", null ],
    [ "Set_background_color_bco", "class_nex_number.html#a8168c315e57d9aec3b61ed4febaa6663", null ],
    [ "Set_background_crop_picc", "class_nex_number.html#a410bd4092a5874541da654edd86a01eb", null ],
    [ "Set_background_image_pic", "class_nex_number.html#aa45acacbde526fce04c699104114d1f1", null ],
    [ "Set_font_color_pco", "class_nex_number.html#ab1836d2d570fca4cd707acecc4b67dea", null ],
    [ "Set_number_lenth", "class_nex_number.html#a045519a466875775d561e54176c459ad", null ],
    [ "Set_place_xcen", "class_nex_number.html#a5e58200c740340cc2666e61b6c80e891", null ],
    [ "Set_place_ycen", "class_nex_number.html#a05aa6572aabe07b48c1b0675904aaadd", null ],
    [ "setFont", "class_nex_number.html#aed567aef79411c5457c81be272218439", null ],
    [ "setValue", "class_nex_number.html#a9cef51f6b76b4ba03a31b2427ffd4526", null ]
];