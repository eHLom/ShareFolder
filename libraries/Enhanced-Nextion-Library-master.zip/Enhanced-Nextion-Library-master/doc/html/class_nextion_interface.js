var class_nextion_interface =
[
    [ "NextionInterface", "class_nextion_interface.html#a71a5caf3fe010525993590d28051050f", null ],
    [ "~NextionInterface", "class_nextion_interface.html#a60f455ff9baf5a6897ecc0c067eddda3", null ],
    [ "GetCurrentBaud", "class_nextion_interface.html#aed0e7876a55d3ef2a12723467406f11b", null ],
    [ "readBytes", "class_nextion_interface.html#ae5a69671ce28fc30188e1d4c76f1e576", null ],
    [ "recvCommand", "class_nextion_interface.html#a3ad8b3db5251be5305129dbe1bbaf0e1", null ],
    [ "recvRetCommandFinished", "class_nextion_interface.html#a1d7c729f014f7435f065585cc7ad4c5c", null ],
    [ "recvRetNumber", "class_nextion_interface.html#a94d2a2b731361933d343ed4dc8b55662", null ],
    [ "recvRetNumber", "class_nextion_interface.html#a0471b58fa293fcb236d82c3d903d91d4", null ],
    [ "recvRetString", "class_nextion_interface.html#afc67bfd3851004ed7a0c192339bc6190", null ],
    [ "recvRetString", "class_nextion_interface.html#a819c48ccca49d2a1aa44e46a0bf9f64d", null ],
    [ "RecvTransparendDataModeFinished", "class_nextion_interface.html#a51fbdfaf2a7b61b78aa560be9b591cc0", null ],
    [ "RecvTransparendDataModeReady", "class_nextion_interface.html#a6b7a51df607099cc028df175d17cf820", null ],
    [ "sendCommand", "class_nextion_interface.html#a4b9a0834cdebee03aea139f6bc790d4d", null ],
    [ "sendRawByte", "class_nextion_interface.html#a92b2af84c33db66bbf35385c299501cf", null ],
    [ "sendRawData", "class_nextion_interface.html#a7f22083248dcc76156a90ff6813f429a", null ]
];