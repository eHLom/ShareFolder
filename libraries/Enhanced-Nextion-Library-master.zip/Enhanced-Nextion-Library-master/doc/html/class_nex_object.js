var class_nex_object =
[
    [ "NexObject", "class_nex_object.html#a2bc1a33d5c3ff7be25a355380e1c0331", null ],
    [ "NexObject", "class_nex_object.html#a7bc14e6f5e386aff7df1d4ec56668a71", null ],
    [ "getObjCid", "class_nex_object.html#a8139b294806c1684fc95b635a33b1b15", null ],
    [ "GetObjectHeight", "class_nex_object.html#a269f087d081df8f21b196666cb13a15f", null ],
    [ "GetObjectWidth", "class_nex_object.html#af280ff5b48acf74547b9a63d7f081a00", null ],
    [ "getObjGlobalPageName", "class_nex_object.html#af5d1ddf5b17c23532ed6aedaad98d2bd", null ],
    [ "getObjName", "class_nex_object.html#a58645a6bf065f9cc29044d40d7d90108", null ],
    [ "getObjPageName", "class_nex_object.html#af2a8f0da8ec20c696f2aaaf96197a798", null ],
    [ "getObjPid", "class_nex_object.html#a67621e5d7bcfb50c1a1bbc4ad1020352", null ],
    [ "printObjInfo", "class_nex_object.html#abeff0c61474e8b3ce6bac76771820b64", null ],
    [ "refresh", "class_nex_object.html#a66ab3a2e7ad5f9c1428890f318544568", null ],
    [ "setVisible", "class_nex_object.html#af1383e9c00063eb3c68878ad9b890884", null ],
    [ "_cid", "class_nex_object.html#a564c9e310440ec53d5681a04fd94128e", null ],
    [ "_name", "class_nex_object.html#ad8c5333be37dda994fe49c5906c70304", null ],
    [ "_page", "class_nex_object.html#ac2718533c8db4545a6446d60955e69a1", null ],
    [ "_pid", "class_nex_object.html#a21475681bc85214b44046d701d1a6bdd", null ]
];