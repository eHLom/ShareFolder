var class_nex_rtc =
[
    [ "NexRtc", "class_nex_rtc.html#a5423a420d265fb73280ef20c2dce5ef9", null ],
    [ "NexRtc", "class_nex_rtc.html#a2544dd5042923fd138ee4c8e05cf9156", null ],
    [ "~NexRtc", "class_nex_rtc.html#ab85e54b21dfb4fe04760e3b5eefa6604", null ],
    [ "read_rtc_time", "class_nex_rtc.html#a5907833b8cef6ef2623e720a7fe9501d", null ],
    [ "read_rtc_time", "class_nex_rtc.html#aa2c23ac9b3a9e8155fb1c9fec496ff70", null ],
    [ "read_rtc_time", "class_nex_rtc.html#a5c7d7f3c46bc92ac2b46ed4f981692cc", null ],
    [ "write_rtc_time", "class_nex_rtc.html#acd9e74c0098ef55877b5ae070572dae4", null ],
    [ "write_rtc_time", "class_nex_rtc.html#a9c55a15fa0a2b1511162facdc47f78b2", null ],
    [ "write_rtc_time", "class_nex_rtc.html#ab11da59341b52b0f686cb85a058d0962", null ]
];