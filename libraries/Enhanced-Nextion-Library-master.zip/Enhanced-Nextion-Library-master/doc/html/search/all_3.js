var searchData=
[
  ['clear_19',['Clear',['../class_nex_waveform.html#a3b450578539dc9f77b14273f3d5f3bad',1,'NexWaveform']]],
  ['component_20',['Component',['../group___component.html',1,'']]],
  ['configuration_21',['Configuration',['../group___configuration.html',1,'']]],
  ['connect_22',['connect',['../class_nextion.html#adb719a398efe8ff3dcf25b66b6de0c2f',1,'Nextion']]],
  ['coreapi_23',['CoreAPI',['../group___core_a_p_i.html',1,'']]],
  ['currentpageidcallback_24',['currentPageIdCallback',['../class_nextion.html#aebfa8d976f00a1c4c68163885525954f',1,'Nextion']]]
];
