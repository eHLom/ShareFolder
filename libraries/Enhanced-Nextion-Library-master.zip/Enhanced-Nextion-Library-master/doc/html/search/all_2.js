var searchData=
[
  ['baudrates_18',['baudRates',['../class_nextion.html#ac6e7ce67dbc1f02552513ebc73618c05',1,'Nextion']]]
];
