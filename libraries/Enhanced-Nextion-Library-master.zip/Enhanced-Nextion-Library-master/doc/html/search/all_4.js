var searchData=
[
  ['dbserialbegin_25',['dbSerialBegin',['../group___configuration.html#gabec12d271fea8fd82696961bc9339edf',1,'NexConfig.h']]],
  ['dbserialprint_26',['dbSerialPrint',['../group___configuration.html#gaf018322c574c0f39d5feb76995cdf2d6',1,'NexConfig.h']]],
  ['dbserialprintln_27',['dbSerialPrintln',['../group___configuration.html#ga7792c838c043fae9a630823f1c328a30',1,'NexConfig.h']]],
  ['detachpop_28',['detachPop',['../class_nex_touch.html#af656640c1078a553287a68bf792dd291',1,'NexTouch']]],
  ['detachpush_29',['detachPush',['../class_nex_touch.html#a2bc36096119534344c2bcd8021b93289',1,'NexTouch']]],
  ['detachtimer_30',['detachTimer',['../class_nex_timer.html#a365d08df4623ce8a146e73ff9204d5cb',1,'NexTimer']]],
  ['digital_5fread_31',['digital_read',['../class_nex_gpio.html#a36386b97898f0960abda51c6010378eb',1,'NexGpio']]],
  ['digital_5fwrite_32',['digital_write',['../class_nex_gpio.html#aaea4cb428fa0a2e26927073c20ed64ac',1,'NexGpio']]],
  ['disable_33',['disable',['../class_nex_scrolltext.html#a909b5ec3d9b01a29715bf616dfafaeee',1,'NexScrolltext::disable()'],['../class_nex_timer.html#ae016d7d39ede6cf813221b26691809f1',1,'NexTimer::disable()']]]
];
