var searchData=
[
  ['findbaud_36',['findBaud',['../class_nextion.html#ac77c90de85cf2c64dbf592c00291da4c',1,'Nextion']]]
];
