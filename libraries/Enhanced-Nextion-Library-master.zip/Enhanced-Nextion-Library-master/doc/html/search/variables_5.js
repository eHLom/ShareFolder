var searchData=
[
  ['m_5fbaud_538',['m_baud',['../class_nextion.html#a5f12313a0009e0663eac56e31e082c88',1,'Nextion']]],
  ['m_5fhight_539',['m_hight',['../class_nex_waveform.html#ad1fc6f90eecb3bfcc3cf5676c8bd6a0f',1,'NexWaveform']]],
  ['m_5fmaxval_540',['m_maxVal',['../class_nex_waveform.html#ad5d681f7164a71e0884570e504a1b073',1,'NexWaveform']]],
  ['m_5fminval_541',['m_minVal',['../class_nex_waveform.html#ac4cca8cb25847ee3384a008c5f7622dc',1,'NexWaveform']]],
  ['m_5fnexserial_542',['m_nexSerial',['../class_nextion.html#a232d60b4debad98eec88d746dfb14ee1',1,'Nextion']]],
  ['m_5fnexserialtype_543',['m_nexSerialType',['../class_nextion.html#a663f8ac60dd1151a72d3690d5a4f08eb',1,'Nextion']]],
  ['m_5fnext_544',['m_next',['../structnex_queued_event.html#a4cbcd7e2488fe929ae75b8c55bc69790',1,'nexQueuedEvent']]],
  ['m_5fnextion_545',['m_nextion',['../class_nextion_if.html#ab212abc68a1656a719328f8f4800d648',1,'NextionIf']]],
  ['m_5fqueuedevents_546',['m_queuedEvents',['../class_nextion.html#aa5dda6ac89808556735f5fb1e250ddfa',1,'Nextion']]],
  ['m_5fscale_547',['m_scale',['../class_nex_waveform.html#af70a542ba57fac7ad9da2b829c122cdf',1,'NexWaveform']]]
];
