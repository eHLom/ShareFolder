var searchData=
[
  ['enable_34',['enable',['../class_nex_scrolltext.html#a6941c1a200d0e4f913c5b37a7114b33a',1,'NexScrolltext::enable()'],['../class_nex_timer.html#a01c146befad40fc0321891ac69e75710',1,'NexTimer::enable()']]],
  ['event_5fdata_35',['event_data',['../structnex_queued_event.html#a259d03e4d27b347c76384cab768af5dd',1,'nexQueuedEvent']]]
];
