var searchData=
[
  ['license_2emd_87',['license.md',['../license_8md.html',1,'']]],
  ['license_88',['license',['../md_license.html',1,'']]]
];
