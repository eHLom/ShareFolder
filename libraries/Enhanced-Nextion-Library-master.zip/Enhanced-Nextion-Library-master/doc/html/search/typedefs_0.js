var searchData=
[
  ['nextoucheventcb_553',['NexTouchEventCb',['../group___touch_event.html#ga95f5c2ce3d34b0b7e7d2cac3076a768e',1,'NexTouch.h']]]
];
