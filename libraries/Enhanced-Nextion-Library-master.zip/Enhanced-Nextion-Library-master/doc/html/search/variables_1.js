var searchData=
[
  ['automaticsleepcallback_533',['automaticSleepCallback',['../class_nextion.html#af2a0f9a92270df75c04f2ade7736732f',1,'Nextion']]],
  ['automaticwakeupcallback_534',['automaticWakeUpCallback',['../class_nextion.html#a5191ad9e56527106cda76c6879043a08',1,'Nextion']]]
];
