var searchData=
[
  ['addvalue_9',['addValue',['../class_nex_waveform.html#ad70ab7ace95de034229770bb3af73e55',1,'NexWaveform']]],
  ['addvalues_10',['addValues',['../class_nex_waveform.html#ad24ac8029249c5a4772bb9bb1ce3c618',1,'NexWaveform']]],
  ['analog_5fwrite_11',['analog_write',['../class_nex_gpio.html#af21eb91b041d149193bc716202d4a462',1,'NexGpio']]],
  ['appendtext_12',['appendText',['../class_nex_text.html#a7603acf98170cef152ccd028bc5abaf3',1,'NexText']]],
  ['attachpop_13',['attachPop',['../class_nex_touch.html#a1fa1ebf87382713fccc3dc551c06dd1e',1,'NexTouch']]],
  ['attachpush_14',['attachPush',['../class_nex_button.html#a80db69eea0c3eb00a008117311828071',1,'NexButton::attachPush()'],['../class_nex_checkbox.html#a273e23a7616defd20a417c2f200bcc75',1,'NexCheckbox::attachPush()'],['../class_nex_radio.html#add813cfba61e509b8e99b56a429ed670',1,'NexRadio::attachPush()'],['../class_nex_touch.html#a31a97db91f2f710b53aec071b8065e8f',1,'NexTouch::attachPush()'],['../class_nex_variable.html#a01e5fd5361cb7603a1a6bfbde09b6806',1,'NexVariable::attachPush()']]],
  ['attachtimer_15',['attachTimer',['../class_nex_timer.html#a69096d5641c6977d879b1368d41bdc7d',1,'NexTimer']]],
  ['automaticsleepcallback_16',['automaticSleepCallback',['../class_nextion.html#af2a0f9a92270df75c04f2ade7736732f',1,'Nextion']]],
  ['automaticwakeupcallback_17',['automaticWakeUpCallback',['../class_nextion.html#a5191ad9e56527106cda76c6879043a08',1,'Nextion']]]
];
