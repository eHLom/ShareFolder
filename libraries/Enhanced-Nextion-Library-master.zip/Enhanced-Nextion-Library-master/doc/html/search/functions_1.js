var searchData=
[
  ['clear_379',['Clear',['../class_nex_waveform.html#a3b450578539dc9f77b14273f3d5f3bad',1,'NexWaveform']]],
  ['connect_380',['connect',['../class_nextion.html#adb719a398efe8ff3dcf25b66b6de0c2f',1,'Nextion']]]
];
