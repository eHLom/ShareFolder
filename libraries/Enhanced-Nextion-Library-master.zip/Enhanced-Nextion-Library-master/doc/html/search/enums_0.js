var searchData=
[
  ['serialtype_554',['serialType',['../class_nextion.html#a8890e51464c5c6f93e05d4a2420217dc',1,'Nextion']]]
];
