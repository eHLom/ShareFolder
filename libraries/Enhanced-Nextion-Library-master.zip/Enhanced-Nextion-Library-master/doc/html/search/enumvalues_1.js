var searchData=
[
  ['sw_557',['SW',['../class_nextion.html#a8890e51464c5c6f93e05d4a2420217dcaa89fb2490712a9b062a108a550115b6d',1,'Nextion']]]
];
