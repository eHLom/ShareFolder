var searchData=
[
  ['event_5fdata_537',['event_data',['../structnex_queued_event.html#a259d03e4d27b347c76384cab768af5dd',1,'nexQueuedEvent']]]
];
