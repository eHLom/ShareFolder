var searchData=
[
  ['enable_387',['enable',['../class_nex_scrolltext.html#a6941c1a200d0e4f913c5b37a7114b33a',1,'NexScrolltext::enable()'],['../class_nex_timer.html#a01c146befad40fc0321891ac69e75710',1,'NexTimer::enable()']]]
];
