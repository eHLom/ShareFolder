var searchData=
[
  ['touchcoordinatecallback_284',['touchCoordinateCallback',['../class_nextion.html#a951cde4126a1f70f7294d6126b096901',1,'Nextion']]],
  ['touchevent_285',['TouchEvent',['../group___touch_event.html',1,'']]],
  ['toucheventinsleepmodecallback_286',['touchEventInSleepModeCallback',['../class_nextion.html#af557c4d26e864cdee80ff251a4ab7c25',1,'Nextion']]]
];
