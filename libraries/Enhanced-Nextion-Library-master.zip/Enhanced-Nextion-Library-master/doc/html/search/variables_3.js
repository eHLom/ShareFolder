var searchData=
[
  ['currentpageidcallback_536',['currentPageIdCallback',['../class_nextion.html#aebfa8d976f00a1c4c68163885525954f',1,'Nextion']]]
];
