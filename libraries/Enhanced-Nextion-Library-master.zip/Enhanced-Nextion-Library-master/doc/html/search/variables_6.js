var searchData=
[
  ['nextionreadycallback_548',['nextionReadyCallback',['../class_nextion.html#a53917ee85316bdbb65a0b835953ce072',1,'Nextion']]],
  ['nextionstartupcallback_549',['nextionStartupCallback',['../class_nextion.html#a3d753a2fb4365352720352570b890c44',1,'Nextion']]]
];
