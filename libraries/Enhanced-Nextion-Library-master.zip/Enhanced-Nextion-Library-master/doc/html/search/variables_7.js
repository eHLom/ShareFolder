var searchData=
[
  ['startsdupgradecallback_550',['startSdUpgradeCallback',['../class_nextion.html#ad93633330beffc17a6fc360d383f5cf6',1,'Nextion']]]
];
