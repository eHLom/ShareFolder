var searchData=
[
  ['hw_555',['HW',['../class_nextion.html#a8890e51464c5c6f93e05d4a2420217dca04244d887124f84916bbfbd103ac4142',1,'Nextion']]],
  ['hw_5fusbcon_556',['HW_USBCON',['../class_nextion.html#a8890e51464c5c6f93e05d4a2420217dca94960f4e33135b23dd13b15b9315c163',1,'Nextion']]]
];
