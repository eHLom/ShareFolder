var class_nex_waveform =
[
    [ "NexWaveform", "class_nex_waveform.html#a844acf4ad585a417d52d923de440aebf", null ],
    [ "NexWaveform", "class_nex_waveform.html#a76a8b86c0559bde982a13f976da0cd75", null ],
    [ "NexWaveform", "class_nex_waveform.html#af6a09cd5ec439d63ec5086dbf3cfc53b", null ],
    [ "addValue", "class_nex_waveform.html#ad70ab7ace95de034229770bb3af73e55", null ],
    [ "addValues", "class_nex_waveform.html#ad24ac8029249c5a4772bb9bb1ce3c618", null ],
    [ "Clear", "class_nex_waveform.html#a3b450578539dc9f77b14273f3d5f3bad", null ],
    [ "Get_background_color_bco", "class_nex_waveform.html#a61a0d6c8da7e7bfcba8e78b1ddd2cb76", null ],
    [ "Get_channel_color", "class_nex_waveform.html#abef55fe5df27accddefa671494bb6837", null ],
    [ "Get_grid_color_gdc", "class_nex_waveform.html#a841232b523021965c1372caa8a8b978a", null ],
    [ "Get_grid_height_gdh", "class_nex_waveform.html#aef62c946717e090a44843a4faa6cbccd", null ],
    [ "Get_grid_width_gdw", "class_nex_waveform.html#a151321ce6ac8e340f3f7979dcb3514dc", null ],
    [ "ScaleToForm", "class_nex_waveform.html#ae7261431f2c441f7a104c729bd0a4d72", null ],
    [ "Set_background_color_bco", "class_nex_waveform.html#aefec5eb25ee698c8c940c9190d60b696", null ],
    [ "Set_channel_color", "class_nex_waveform.html#ad886e8280a67dd6e12748367b9e9683e", null ],
    [ "Set_grid_color_gdc", "class_nex_waveform.html#ab396211f736824a0210446e68dc3edf4", null ],
    [ "Set_grid_height_gdh", "class_nex_waveform.html#a85e776a5347c22efd9abe9bb8cfdbddb", null ],
    [ "Set_grid_width_gdw", "class_nex_waveform.html#a41cb6d8b1ff6c309d1c4e8a1f73304fe", null ],
    [ "m_hight", "class_nex_waveform.html#ad1fc6f90eecb3bfcc3cf5676c8bd6a0f", null ],
    [ "m_maxVal", "class_nex_waveform.html#ad5d681f7164a71e0884570e504a1b073", null ],
    [ "m_minVal", "class_nex_waveform.html#ac4cca8cb25847ee3384a008c5f7622dc", null ],
    [ "m_scale", "class_nex_waveform.html#af70a542ba57fac7ad9da2b829c122cdf", null ]
];