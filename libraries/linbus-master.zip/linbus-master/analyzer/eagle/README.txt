Feb 2014.

The Linbus Beeeper board was design to have only two layers and
comply with design rules of inexpensive PCB houses. The components
sizes were selected to be large enough for manual soldering by 
hobbyist (e.g. 805 SMD resistors). 

Most PCB houses accept Eagle files so to order you just need to
upload the Eagle file, without having to generate gerber files.

For example, in the US oshpark.com will manufacture 3 boards for
a total of $10 including shipping (as of Jan 2014).

If you are ordering from ospark.com, you may find the board already
ready for ordering at http://oshpark.com/profiles/zapta (there is
no special deal or commission when ordering via this link, just
saving you the need to upload the file).



