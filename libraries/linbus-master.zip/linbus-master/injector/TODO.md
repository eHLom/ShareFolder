TODO list for the Linbus Injector.

SCHEMATIC

LAYOUT

SOFTWARE

MISCELLANEOUS
* Add BOM document.
* Improve documentation (e.g. how to attache to the car).




