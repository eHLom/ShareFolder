var searchData=
[
  ['iscloser',['isCloser',['../class_distance_sensor.html#aaeb8f74df2282153123c30e07c775724',1,'DistanceSensor']]],
  ['isfarther',['isFarther',['../class_distance_sensor.html#a4135f6f4c351c5f0d001dbedab118dc4',1,'DistanceSensor']]]
];
