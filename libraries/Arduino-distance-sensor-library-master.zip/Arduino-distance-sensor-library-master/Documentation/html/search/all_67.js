var searchData=
[
  ['getdistancecentimeter',['getDistanceCentimeter',['../class_distance_g_p2_y0_a21_y_k.html#a3f1923b1357c540d9b45eae3650c83e8',1,'DistanceGP2Y0A21YK::getDistanceCentimeter()'],['../class_distance_g_p2_y0_a41_s_k.html#a2f0f8b6df63c05284c8df23a363715d1',1,'DistanceGP2Y0A41SK::getDistanceCentimeter()'],['../class_ultrasonic_distance_sensor.html#aa8093d0c333e6ce180f1708ca99ae2c1',1,'UltrasonicDistanceSensor::getDistanceCentimeter()']]],
  ['getdistanceinch',['getDistanceInch',['../class_ultrasonic_distance_sensor.html#a3a8b89cb52091f36dd87ed6afff9617a',1,'UltrasonicDistanceSensor']]],
  ['getdistanceraw',['getDistanceRaw',['../class_analog_distance_sensor.html#afd371c93052963334be7677f08dae5b6',1,'AnalogDistanceSensor']]],
  ['getdistancetime',['getDistanceTime',['../class_distance_s_r_f04.html#a019a569fa5bcca56ed17bfab386d8f9d',1,'DistanceSRF04']]],
  ['getdistancevolt',['getDistanceVolt',['../class_analog_distance_sensor.html#af677a29eb12b0349ff34120c1d87ccd3',1,'AnalogDistanceSensor']]]
];
