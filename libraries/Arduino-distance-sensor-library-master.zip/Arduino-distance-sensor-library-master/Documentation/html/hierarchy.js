var hierarchy =
[
    [ "DistanceSensor", "class_distance_sensor.html", [
      [ "AnalogDistanceSensor", "class_analog_distance_sensor.html", [
        [ "DistanceGP2Y0A21YK", "class_distance_g_p2_y0_a21_y_k.html", null ],
        [ "DistanceGP2Y0A41SK", "class_distance_g_p2_y0_a41_s_k.html", null ]
      ] ],
      [ "UltrasonicDistanceSensor", "class_ultrasonic_distance_sensor.html", [
        [ "DistanceSRF04", "class_distance_s_r_f04.html", null ]
      ] ]
    ] ]
];