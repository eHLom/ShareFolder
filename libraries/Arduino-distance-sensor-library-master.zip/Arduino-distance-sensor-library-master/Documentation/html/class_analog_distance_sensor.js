var class_analog_distance_sensor =
[
    [ "AnalogDistanceSensor", "class_analog_distance_sensor.html#a089770021c7ba24cf24f6ad20b8616b8", null ],
    [ "begin", "class_analog_distance_sensor.html#aab16a8975b46d82ac9fd7077e839f35c", null ],
    [ "begin", "class_analog_distance_sensor.html#a57a38f5fd395392d6a68e57bf2e86d4b", null ],
    [ "getDistanceRaw", "class_analog_distance_sensor.html#afd371c93052963334be7677f08dae5b6", null ],
    [ "getDistanceVolt", "class_analog_distance_sensor.html#af677a29eb12b0349ff34120c1d87ccd3", null ],
    [ "setARefVoltage", "class_analog_distance_sensor.html#a7e8c18ea2a45d5b683b6cb04139396c8", null ],
    [ "_refVoltage", "class_analog_distance_sensor.html#a9afcdb39f6bf3b672b4e334aa5bcc360", null ]
];